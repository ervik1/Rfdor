import os, re, sqlite3, shutil, subprocess, tempfile, json
from pathlib import Path
from datetime import date, datetime, timedelta
from copy import copy

from flask import Flask, render_template, request, jsonify, redirect, url_for, send_file, abort
import openpyxl
from docx import Document

BASE = Path(__file__).resolve().parent.parent
DATA = BASE / "data"
OUTPUT = BASE / "output"
DB = DATA / "doverennosti.db"
TEMPLATE = DATA / "Доверености 2026_template.xlsx"
PDF_TEMPLATE = DATA / "Доверенность_PDF_template.docx"
SEED_TEMPLATE = BASE / "seed" / "Доверености 2026_template.xlsx"
SEED_PDF_TEMPLATE = BASE / "seed" / "Доверенность_PDF_template.docx"

OUTPUT.mkdir(parents=True, exist_ok=True)
DATA.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)


def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con


def cols(con, table):
    return {r[1] for r in con.execute(f"PRAGMA table_info({table})")}


def ensure_schema():
    con = sqlite3.connect(DB)
    con.executescript("""
    CREATE TABLE IF NOT EXISTS suppliers(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE, inn TEXT, legal_form TEXT, email TEXT
    );
    CREATE TABLE IF NOT EXISTS warehouses(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE, address TEXT NOT NULL, contact TEXT
    );
    CREATE TABLE IF NOT EXISTS ru(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT UNIQUE, city TEXT, recipient TEXT, inn TEXT, address TEXT,
      rate REAL, delivery_days INTEGER
    );
    CREATE TABLE IF NOT EXISTS drivers(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      passport_series TEXT NOT NULL, passport_number TEXT NOT NULL,
      surname TEXT NOT NULL, first_name TEXT NOT NULL, patronymic TEXT,
      citizenship TEXT, birth_date TEXT, issued_by TEXT, issue_date TEXT,
      registration TEXT, subdivision_code TEXT, phone TEXT,
      UNIQUE(passport_series,passport_number)
    );
    CREATE TABLE IF NOT EXISTS vehicles(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      plate TEXT NOT NULL UNIQUE, make TEXT, trailer_plate TEXT, driver_id INTEGER
    );
    CREATE TABLE IF NOT EXISTS powers(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      request_number TEXT NOT NULL, created_at TEXT NOT NULL,
      power_date TEXT, supplier_id INTEGER, warehouse_id INTEGER,
      driver_id INTEGER, vehicle_id INTEGER, ru_id INTEGER,
      yandex_most TEXT, etrn TEXT, cargo TEXT, quantity REAL, places REAL,
      contract_no TEXT, shipment_date TEXT, unload_date TEXT, rate REAL,
      ml TEXT, tk TEXT, application TEXT, arrival_date TEXT, output_file TEXT, pdf_file TEXT
    );
    CREATE TABLE IF NOT EXISTS cargo_items(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      power_id INTEGER NOT NULL,
      cargo TEXT NOT NULL, quantity REAL, places REAL,
      FOREIGN KEY(power_id) REFERENCES powers(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS settings(
      key TEXT PRIMARY KEY,
      value TEXT
    );
    """)
    # Backward-compatible migrations. Existing data is never deleted.
    for table, additions in {
        "suppliers": [("inn","TEXT"),("legal_form","TEXT"),("email","TEXT")],
        "warehouses": [("contact","TEXT")],
        "ru": [("code","TEXT"),("delivery_days","INTEGER"),("city","TEXT"),
               ("recipient","TEXT"),("inn","TEXT"),("address","TEXT"),("rate","REAL")],
        "drivers": [("subdivision_code","TEXT"),("phone","TEXT")],
        "vehicles": [("make","TEXT"),("trailer_plate","TEXT"),("driver_id","INTEGER")],
        "powers": [
            ("power_date","TEXT"),("yandex_most","TEXT"),("etrn","TEXT"),
            ("ml","TEXT"),("tk","TEXT"),("application","TEXT"),("arrival_date","TEXT"),
            ("rate","REAL"),("unload_date","TEXT"),("shipment_date","TEXT"),
            ("pdf_file","TEXT"),("output_file","TEXT"),("cargo","TEXT"),
            ("quantity","REAL"),("places","REAL"),("contract_no","TEXT")
        ]
    }.items():
        existing = cols(con, table)
        for name, typ in additions:
            if name not in existing:
                con.execute(f"ALTER TABLE {table} ADD COLUMN {name} {typ}")
    con.commit()
    con.close()


ensure_schema()

def get_setting(key, default=""):
    con = db()
    row = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    con.close()
    return row["value"] if row else default

def set_setting(key, value):
    con = db()
    con.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
    con.commit()
    con.close()

REPORT_TEMPLATE = DATA / "Отчет движение_template.xlsx"
SEED_REPORT_TEMPLATE = BASE / "seed" / "Отчет движение_template.xlsx"
if not REPORT_TEMPLATE.exists() and SEED_REPORT_TEMPLATE.exists():
    shutil.copy2(SEED_REPORT_TEMPLATE, REPORT_TEMPLATE)


def week_bounds(value):
    d = date.fromisoformat(value)
    start = d - timedelta(days=d.weekday())
    end = start + timedelta(days=6)
    return start, end


def make_weekly_report(rows, start, end, out):
    if REPORT_TEMPLATE.exists():
        wb = openpyxl.load_workbook(REPORT_TEMPLATE)
    else:
        wb = openpyxl.Workbook()
    # Keep the user's template layout, but use the actual ISO week name.
    old = wb.active
    target_name = f"{start.isocalendar().week} неделя"
    if old.title != target_name:
        if target_name in wb.sheetnames:
            del wb[target_name]
        old.title = target_name
    ws = old
    # Clear data rows while preserving the template header and formatting.
    if ws.max_row >= 3:
        for row in ws.iter_rows(min_row=3, max_row=ws.max_row, min_col=1, max_col=13):
            for cell in row:
                cell.value = None
    # Use row 3 as the template row for every report line.
    template_row = 3
    from copy import copy
    def clone_style(src_row, dst_row):
        if dst_row == src_row:
            return
        for col in range(1, 14):
            src, dst = ws.cell(src_row, col), ws.cell(dst_row, col)
            if src.has_style:
                dst._style = copy(src._style)
            dst.number_format = src.number_format
            dst.alignment = copy(src.alignment)
            dst.protection = copy(src.protection)
        ws.row_dimensions[dst_row].height = ws.row_dimensions[src_row].height

    for idx, r in enumerate(rows, start=3):
        clone_style(template_row, idx)
        shipment = r["shipment_date"] or ""
        order_date = ""
        if shipment:
            try:
                order_date = (date.fromisoformat(shipment) - timedelta(days=1)).isoformat()
            except Exception:
                order_date = shipment
        full_driver = " ".join(x for x in [r["driver_surname"], r["driver_first"], r["driver_patronymic"]] if x)
        phone = phone_fmt(r["driver_phone"]) if r["driver_phone"] else ""
        ws.cell(idx,1).value = order_date
        ws.cell(idx,2).value = r["request_number"] or ""
        ws.cell(idx,3).value = r["warehouse_name"] or ""
        ws.cell(idx,4).value = r["ru_address"] or ""
        ws.cell(idx,5).value = r["yandex_most"] or ""
        ws.cell(idx,6).value = shipment
        ws.cell(idx,7).value = r["unload_date"] or ""
        ws.cell(idx,8).value = r["arrival_date"] or ""
        ws.cell(idx,9).value = r["tk"] or ""
        ws.cell(idx,10).value = r["vehicle_plate"] or ""
        ws.cell(idx,11).value = full_driver
        ws.cell(idx,12).value = phone
        ws.cell(idx,13).value = ""
        for col in (1,6,7,8):
            ws.cell(idx,col).number_format = "dd.mm.yyyy"
    # Remove unused sample rows but keep at least the template row.
    if ws.max_row > max(3, 2 + len(rows)):
        ws.delete_rows(max(3, 3 + len(rows)), ws.max_row - max(3, 2 + len(rows)))
    ws.freeze_panes = "A3"
    wb.save(out)
    openpyxl.load_workbook(out, read_only=True).close()

if not TEMPLATE.exists() and SEED_TEMPLATE.exists():
    shutil.copy2(SEED_TEMPLATE, TEMPLATE)
if not PDF_TEMPLATE.exists() and SEED_PDF_TEMPLATE.exists():
    shutil.copy2(SEED_PDF_TEMPLATE, PDF_TEMPLATE)


def norm(s):
    # Excel may return passport/plate cells as integers. Always convert to text first.
    if s is None:
        return ""
    if isinstance(s, float) and s.is_integer():
        s = int(s)
    return re.sub(r"[^0-9A-ZА-ЯЁ]", "", str(s).upper())


def plate_norm(s):
    if s is None:
        return ""
    if isinstance(s, float) and s.is_integer():
        s = int(s)
    return re.sub(r"[\s\-]", "", str(s).upper())


def digits(s):
    if s is None:
        return ""
    return re.sub(r"\D", "", str(s))


def code_fmt(s):
    d = digits(s)[:6]
    return d[:3] + ("-" + d[3:] if len(d) > 3 else "")


def phone_digits(s):
    d = digits(s)
    if d.startswith("8"):
        d = "7" + d[1:]
    if d and not d.startswith("7"):
        d = "7" + d
    return d[:11]


def phone_fmt(s):
    d = phone_digits(s)
    if len(d) == 11 and d.startswith("7"):
        return f"7({d[1:4]}) {d[4:7]}{d[7:11]}"
    return s or ""


def safe_name(s):
    return re.sub(r'[\\/:*?"<>|]+', "_", (s or "").strip()) or "доверенность"


def parse_float(s):
    s = (s or "").strip().replace(",", ".")
    return float(s) if s else None


def date_ru(s):
    if not s:
        return ""
    try:
        return date.fromisoformat(s).strftime("%d.%m.%Y")
    except Exception:
        return s


def first_empty(ws):
    for r in range(5, ws.max_row + 2):
        if ws.cell(r, 1).value in (None, ""):
            return r
    return ws.max_row + 1


def copy_row_style(ws, src_row, dst_row):
    for col in range(1, ws.max_column + 1):
        src, dst = ws.cell(src_row, col), ws.cell(dst_row, col)
        if src.has_style:
            dst._style = copy(src._style)
        if src.number_format:
            dst.number_format = src.number_format
        if src.alignment:
            dst.alignment = copy(src.alignment)
        if src.protection:
            dst.protection = copy(src.protection)


def fetch_power_context(con, f):
    s = con.execute("SELECT * FROM suppliers WHERE id=?", (int(f["supplier_id"]),)).fetchone()
    w = con.execute("SELECT * FROM warehouses WHERE id=?", (int(f["warehouse_id"]),)).fetchone()
    r = con.execute("SELECT * FROM ru WHERE id=?", (int(f["ru_id"]),)).fetchone()
    d = con.execute("SELECT * FROM drivers WHERE id=?", (int(f["driver_id"]),)).fetchone() if f.get("driver_id") else None
    v = con.execute("SELECT * FROM vehicles WHERE id=?", (int(f["vehicle_id"]),)).fetchone() if f.get("vehicle_id") else None
    return s, w, r, d, v


def make_excel(f, cargo_items, out):
    wb = openpyxl.load_workbook(TEMPLATE, data_only=False)
    cached = openpyxl.load_workbook(TEMPLATE, data_only=True)
    ws, cv = wb["Расход"], cached["Расход"]

    # Freeze formula results to the values already stored in the original template.
    for rr in range(1, ws.max_row + 1):
        for cc in range(1, ws.max_column + 1):
            cell = ws.cell(rr, cc)
            if isinstance(cell.value, str) and cell.value.startswith("="):
                cell.value = cv.cell(rr, cc).value

    con = db()
    s, w, r, d, v = fetch_power_context(con, f)
    con.close()

    unload = ""
    if f.get("shipment_date") and r and r["delivery_days"] is not None:
        unload = (date.fromisoformat(f["shipment_date"]) +
                  timedelta(days=int(r["delivery_days"]))).isoformat()

    base_map = {
        "A": f.get("request_number", "").strip(),
        "B": s["name"] if s else "",
        "C": w["name"] if w else "",
        "D": d["surname"] if d else "",
        "E": d["first_name"] if d else "",
        "F": d["patronymic"] if d else "",
        "G": d["citizenship"] if d else "",
        "K": d["passport_series"] if d else "",
        "L": d["passport_number"] if d else "",
        "M": d["issued_by"] if d else "",
        "Q": d["registration"] if d else "",
        "R": v["make"] if v else "",
        "S": v["plate"] if v else "",
        "T": v["trailer_plate"] if v else "",
        "U": phone_fmt(d["phone"]) if d else "",
        "V": r["recipient"] if r else "",
        "W": r["inn"] if r else "",
        "X": f.get("yandex_most", "").strip(),
        "Y": r["code"] if r else "",
        "AC": f.get("contract_no", "").strip(),
        "AD": f.get("shipment_date", "").strip(),
        "AE": unload,
        "AF": s["inn"] if s else "",
        "AG": w["contact"] if w else "",
        "AH": w["address"] if w else "",
        "AI": r["delivery_days"] if r else None,
        "AJ": r["rate"] if r else None,
        "AK": f.get("ml", "").strip(),
        "AM": f.get("tk", "").strip(),
        "AN": f.get("application", "").strip(),
        "AO": f.get("arrival_date", "").strip(),
        "AL": s["legal_form"] if s else "",
        "AT": s["email"] if s else "",
        "AW": date.fromisoformat(f["shipment_date"]).isocalendar().week if f.get("shipment_date") else ""
    }
    if d and d["birth_date"]:
        try:
            x = date.fromisoformat(d["birth_date"])
            base_map.update({"H": x.day, "I": x.month, "J": x.year})
        except Exception:
            pass
    if d and d["issue_date"]:
        try:
            x = date.fromisoformat(d["issue_date"])
            base_map.update({"N": x.day, "O": x.month, "P": x.year})
        except Exception:
            pass

    items = cargo_items or [{"cargo": f.get("cargo", ""), "quantity": f.get("quantity"), "places": f.get("places")}]
    for item in items:
        row = first_empty(ws)
        copy_row_style(ws, 4, row)
        m = dict(base_map)
        m["Z"] = item.get("cargo", "").strip()
        m["AA"] = item.get("quantity")
        m["AB"] = item.get("places")
        for col, val in m.items():
            ws[f"{col}{row}"] = val

    # The user's original Excel template remains structurally unchanged.
    # RU and данные are removed after formulas have been materialized.
    for sh in ("RU", "данные"):
        if sh in wb.sheetnames:
            del wb[sh]
    wb.save(out)
    openpyxl.load_workbook(out, read_only=True).close()


def replace_docx_text(doc, mapping):
    # Template placeholders are replaced while keeping the document as a DOCX.
    for p in doc.paragraphs:
        txt = p.text
        new = txt
        for key, value in mapping.items():
            new = new.replace(key, str(value or ""))
        if new != txt:
            p.text = new
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    txt = p.text
                    new = txt
                    for key, value in mapping.items():
                        new = new.replace(key, str(value or ""))
                    if new != txt:
                        p.text = new


def make_pdf(f, cargo_items, out_pdf):
    con = db()
    s, w, r, d, v = fetch_power_context(con, f)
    con.close()

    if not PDF_TEMPLATE.exists():
        raise RuntimeError("Не найден PDF-шаблон доверенности.")

    doc = Document(PDF_TEMPLATE)
    items = cargo_items or [{"cargo": f.get("cargo", ""), "quantity": f.get("quantity"), "places": f.get("places")}]
    cargo_lines = []
    for i, item in enumerate(items, 1):
        q = item.get("quantity")
        pl = item.get("places")
        line = f"{i}. {item.get('cargo','')}"
        if q not in (None, ""):
            line += f" — {q} кг"
        if pl not in (None, ""):
            line += f", {pl} мест"
        cargo_lines.append(line)

    mapping = {
        "{1}": f.get("request_number", ""),
        "{2}": s["name"] if s else "",
        "{3}": w["name"] if w else "",
        "{4}": d["surname"] if d else "",
        "{5}": d["first_name"] if d else "",
        "{6}": d["patronymic"] if d else "",
        "{11}": d["passport_series"] if d else "",
        "{12}": d["passport_number"] if d else "",
        "{13}": d["citizenship"] if d else "",
        "{14}": date.fromisoformat(d["issue_date"]).day if d and d["issue_date"] else "",
        "{15}": date.fromisoformat(d["issue_date"]).month if d and d["issue_date"] else "",
        "{16}": date.fromisoformat(d["issue_date"]).year if d and d["issue_date"] else "",
        "{18}": v["make"] if v else "",
        "{19}": v["plate"] if v else "",
        "{20}": v["trailer_plate"] if v else "",
        "{21}": d["registration"] if d else "",
        "{22}": r["recipient"] if r else "",
        "{23}": r["inn"] if r else "",
        "{24}": r["address"] if r else "",
        "{25}": r["address"] if r else "",
        "{30}": f"Дата отгрузки: {date_ru(f.get('shipment_date'))}. Дата прибытия: {date_ru(f.get('arrival_date'))}. Я.Магистраль: {f.get('yandex_most','')}. ЭТрН: {f.get('etrn','')}. МЛ: {f.get('ml','')}. ТК: {f.get('tk','')}. Применение: {f.get('application','')}",
    }

    # Remove the original single cargo placeholder paragraph and insert all items.
    cargo_paras = []
    for p in doc.paragraphs:
        if "{%index%}" in p.text:
            cargo_paras.append(p)
    if cargo_paras:
        p = cargo_paras[0]
        parent = p._p.getparent()
        idx = parent.index(p._p)
        for i, line in enumerate(cargo_lines):
            np = doc.add_paragraph(line)
            parent.remove(np._p)
            parent.insert(idx + i, np._p)
        parent.remove(p._p)

    # Replace remaining placeholders. This also handles old single-cargo templates.
    replace_docx_text(doc, mapping)
    # Replace the sample date printed in the supplied template.
    months = ["января","февраля","марта","апреля","мая","июня","июля","августа","сентября","октября","ноября","декабря"]
    if f.get("power_date"):
        try:
            pd = date.fromisoformat(f["power_date"])
            pretty = f"{pd.day} {months[pd.month-1]} {pd.year} г."
            for p in doc.paragraphs:
                if "г. Санкт-Петербург" in p.text:
                    p.text = re.sub(r"\d{1,2}\s+[а-яё]+\s+\d{4}\s+г\.", pretty, p.text)
        except Exception:
            pass

    # Convert via LibreOffice in a temporary directory.
    with tempfile.TemporaryDirectory(prefix="dov_pdf_") as td:
        td = Path(td)
        docx = td / "source.docx"
        doc.save(docx)
        proc = subprocess.run(
            ["libreoffice", "--headless", "--convert-to", "pdf", "--outdir", str(td), str(docx)],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=120
        )
        pdf = td / "source.pdf"
        if proc.returncode != 0 or not pdf.exists():
            raise RuntimeError("LibreOffice не смог сформировать PDF: " + proc.stderr[-1000:])
        shutil.copy2(pdf, out_pdf)


def collect_items(form):
    cargos = form.getlist("cargo[]")
    quantities = form.getlist("quantity[]")
    places = form.getlist("places[]")
    items = []
    for i, cargo in enumerate(cargos):
        cargo = cargo.strip()
        if not cargo:
            continue
        q = parse_float(quantities[i] if i < len(quantities) else "")
        pl = parse_float(places[i] if i < len(places) else "")
        items.append({"cargo": cargo, "quantity": q, "places": pl})
    # Compatibility with old one-line form.
    if not items and form.get("cargo"):
        items = [{"cargo": form.get("cargo").strip(),
                  "quantity": parse_float(form.get("quantity")),
                  "places": parse_float(form.get("places"))}]
    return items



def parse_import_xlsx(path):
    """Parse the two supported Excel order formats into a common structure.
    Supported:
      1) Заказ клиента №...
      2) Печать заказа на перемещение между филиалами №...
    """
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    ws = wb.active
    values = {(r, c): ws.cell(r, c).value for r in range(1, min(ws.max_row, 80)+1)
              for c in range(1, min(ws.max_column, 80)+1)}

    def text(v):
        return str(v).strip() if v is not None else ""

    title = text(values.get((5,3)))
    if title.startswith("Заказ клиента"):
        m = re.search(r"Заказ клиента\s*№\s*([^\s]+)", title, re.I)
        req = m.group(1) if m else ""
        items=[]
        for r in range(15, ws.max_row+1):
            cargo=text(values.get((r,6)))
            if not cargo or cargo.lower().startswith("итого"):
                continue
            qty=values.get((r,51))
            unit=text(values.get((r,55)))
            if isinstance(qty,(int,float)) or qty not in (None,""):
                try: qty=float(str(qty).replace(" ","").replace(",","."))
                except Exception: qty=None
                items.append({"cargo":cargo,"quantity":qty,"places":None,"unit":unit})
        return {"kind":"client_order","request_number":req,"items":items,
                "source_date": title, "source_file": Path(path).name}

    title2=text(values.get((13,1)))
    if title2.startswith("Заказ на перемещение"):
        m=re.search(r"№\s*([^\s]+)",title2,re.I)
        req=m.group(1) if m else ""
        items=[]
        for r in range(18, ws.max_row+1):
            cargo=text(values.get((r,2)))
            if not cargo or cargo.lower().startswith("всего") or cargo.startswith("("):
                continue
            places=values.get((r,10))
            qty=values.get((r,12))
            def num(v):
                if v in (None,""): return None
                try: return float(str(v).replace(" ","").replace("\u00a0","").replace(",","."))
                except Exception: return None
            items.append({"cargo":cargo,"quantity":num(qty),"places":num(places),"unit":text(values.get((r,7)))})
        return {"kind":"transfer_order","request_number":req,"items":items,
                "source_warehouse":text(values.get((2,1))).replace("СО СКЛАДА:","").strip(),
                "source_address":text(values.get((3,2))).replace("Адрес:","").strip(),
                "destination_warehouse":text(values.get((4,1))).replace("НА СКЛАД:","").strip(),
                "destination_address":text(values.get((5,2))).replace("Адрес:","").strip(),
                "ru_site":text(values.get((10,2))).replace("Номер площадки:","").strip(),
                "source_date":title2,"source_file":Path(path).name}
    raise ValueError("Не удалось определить формат Excel. Поддерживаются 'Заказ клиента' и 'Заказ на перемещение между филиалами'.")

@app.post("/api/import-xlsx")
def import_xlsx():
    up=request.files.get("file")
    if not up or not up.filename:
        return jsonify(ok=False,error="Выберите Excel-файл."),400
    if not up.filename.lower().endswith(".xlsx"):
        return jsonify(ok=False,error="Поддерживается только .xlsx."),400
    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tf:
        temp=Path(tf.name)
    try:
        up.save(temp)
        data=parse_import_xlsx(temp)
        return jsonify(ok=True,data=data)
    except Exception as e:
        app.logger.exception("Excel import failed")
        return jsonify(ok=False,error=str(e)),400
    finally:
        temp.unlink(missing_ok=True)


def parse_driver_excel(path):
    """Read driver rows from the user's driver list workbook.

    Expected/current format has two header rows:
    row 1: surname, first name, patronymic, citizenship, ... passport ...
    row 2: date subheaders.
    The parser also tolerates alternative Russian header spellings.
    """
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb.active
    if ws.max_row < 2:
        raise ValueError("Файл Excel пустой.")

    def normh(v):
        return re.sub(r"[^a-zа-яё0-9]", "", str(v or "").lower())

    h1 = [normh(ws.cell(1,c).value) for c in range(1, ws.max_column+1)]
    h2 = [normh(ws.cell(2,c).value) for c in range(1, ws.max_column+1)]

    def find(*names, row=1):
        hs = h1 if row == 1 else h2
        for i, h in enumerate(hs):
            if any(n in h for n in names):
                return i+1
        return None

    c_surname = find("фамилия","surname") or 4
    c_first = find("имя","firstname","first") or 5
    c_pat = find("отчество","patronymic") or 6
    c_cit = find("гражданство","citizenship") or 7
    c_series = find("серия") or 11
    # The first "Номер" column is the order/request number, so passport
    # number must be taken from the column immediately after passport series.
    c_number = (c_series + 1) if c_series else 12
    c_issued = find("кемвыдан","issuedby") or 13
    c_registration = find("прописка","регистрация","registration") or 17
    c_phone = find("телефон","мобильный","phone") or 21
    c_make = find("маркаа","маркаавто") or 18
    c_plate = find("госномер","госномерaм") or 19
    c_trailer = find("госномерприцепа") or 20

    # Exact current workbook: dates are represented by 3 adjacent columns
    # under the second header row: day/month/year.
    birth_trip = None
    issue_trip = None
    for start in range(1, ws.max_column-1):
        vals = h2[start-1:start+2]
        if vals == ["день","месяц","год"]:
            # first trip belongs to birth, second to passport issue
            if birth_trip is None:
                birth_trip = (start, start+1, start+2)
            else:
                issue_trip = (start, start+1, start+2)

    # In the supplied file there are two such triples: H:J and N:P.
    if birth_trip is None:
        # Fallback to the known layout.
        birth_trip = (8,9,10)
    if issue_trip is None:
        issue_trip = (14,15,16)

    def val(row, c):
        return row[c-1].value if c else None

    def clean(v):
        if v is None:
            return ""
        return str(v).strip()

    def date_from_trip(row, trip):
        vals=[]
        for c in trip:
            v=val(row,c)
            if v is None or str(v).strip()=="":
                return ""
            try:
                vals.append(int(float(v)))
            except Exception:
                return ""
        try:
            return date(vals[2], vals[1], vals[0]).isoformat()
        except Exception:
            return ""

    rows=[]
    for ridx in range(3, ws.max_row+1):
        row=list(ws[ridx])
        surname=clean(val(row,c_surname))
        first=clean(val(row,c_first))
        series=norm(val(row,c_series))
        number=norm(val(row,c_number))
        if not surname and not first and not series and not number:
            continue
        if not surname or not first or not series or not number:
            rows.append({"row":ridx,"error":"Не хватает ФИО или серии/номера паспорта."})
            continue
        rows.append({
            "row":ridx,
            "passport_series": series,
            "passport_number": number,
            "surname": surname,
            "first_name": first,
            "patronymic": clean(val(row,c_pat)),
            "citizenship": clean(val(row,c_cit)) or "Россия",
            "birth_date": date_from_trip(row,birth_trip),
            "issued_by": clean(val(row,c_issued)),
            "issue_date": date_from_trip(row,issue_trip),
            "registration": clean(val(row,c_registration)),
            "phone": phone_fmt(val(row,c_phone)),
            "make": clean(val(row,c_make)),
            "plate": plate_norm(val(row,c_plate)),
            "trailer_plate": plate_norm(val(row,c_trailer)),
        })
    return rows


@app.post("/api/import-drivers")
def import_drivers():
    up = request.files.get("file")
    if not up or not up.filename:
        return jsonify(ok=False, error="Выберите Excel-файл."), 400
    if not up.filename.lower().endswith(".xlsx"):
        return jsonify(ok=False, error="Поддерживается только .xlsx."), 400

    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tf:
        temp=Path(tf.name)
    try:
        up.save(temp)
        rows=parse_driver_excel(temp)
        con=db()
        added=0
        updated=0
        skipped=0
        errors=[]
        vehicles_added=0
        vehicles_updated=0

        for item in rows:
            if item.get("error"):
                errors.append(f"Строка {item['row']}: {item['error']}")
                continue

            ps = norm(item.get("passport_series"))
            pn = norm(item.get("passport_number"))
            if not ps or not pn:
                errors.append(f"Строка {item['row']}: нет серии или номера паспорта.")
                continue

            exists=con.execute("""
              SELECT * FROM drivers
              WHERE replace(replace(upper(passport_series),' ',''),'-','')=?
                AND replace(replace(upper(passport_number),' ',''),'-','')=?
            """,(ps,pn)).fetchone()

            driver_values=(ps,pn,item["surname"],item["first_name"],item["patronymic"],
                           item["citizenship"] or "Россия",item["birth_date"],item["issued_by"],
                           item["issue_date"],item["registration"],"",phone_fmt(item["phone"]))

            if exists:
                driver_id=exists["id"]
                # Do not wipe existing data with blanks. Fill only values supplied by Excel.
                fields=["surname","first_name","patronymic","citizenship","birth_date",
                        "issued_by","issue_date","registration","phone"]
                vals=[item["surname"],item["first_name"],item["patronymic"],item["citizenship"] or "Россия",
                      item["birth_date"],item["issued_by"],item["issue_date"],item["registration"],phone_fmt(item["phone"])]
                sets=[]; params=[]
                for fld,val in zip(fields,vals):
                    if val not in (None,""):
                        sets.append(f"{fld}=?"); params.append(val)
                if sets:
                    params.append(driver_id)
                    con.execute(f"UPDATE drivers SET {', '.join(sets)} WHERE id=?",params)
                    updated += 1
                else:
                    skipped += 1
            else:
                con.execute("""
                  INSERT INTO drivers
                  (passport_series,passport_number,surname,first_name,patronymic,citizenship,
                   birth_date,issued_by,issue_date,registration,subdivision_code,phone)
                  VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                """,driver_values)
                driver_id=con.execute("SELECT last_insert_rowid()").fetchone()[0]
                added += 1

            # Vehicle import is independent of whether the driver was new or already existed.
            # This fixes the previous behavior where an existing driver prevented the car from importing.
            vp=plate_norm(item.get("plate"))
            if vp:
                v=con.execute("SELECT * FROM vehicles WHERE upper(replace(replace(plate,' ',''),'-',''))=?",(vp,)).fetchone()
                make=item.get("make","") or ""
                trailer=plate_norm(item.get("trailer_plate"))
                if not v:
                    con.execute(
                        "INSERT INTO vehicles(plate,make,trailer_plate,driver_id) VALUES(?,?,?,?)",
                        (vp,make,trailer,driver_id))
                    vehicles_added += 1
                else:
                    sets=[]; params=[]
                    if make: sets.append("make=?"); params.append(make)
                    if trailer: sets.append("trailer_plate=?"); params.append(trailer)
                    sets.append("driver_id=?"); params.append(driver_id)
                    params.append(v["id"])
                    con.execute(f"UPDATE vehicles SET {', '.join(sets)} WHERE id=?",params)
                    vehicles_updated += 1

        con.commit()
        con.close()
        return jsonify(ok=True, total=len(rows), added=added, updated=updated, skipped=skipped,
                       vehicles_added=vehicles_added, vehicles_updated=vehicles_updated, errors=errors)
    except Exception as e:
        app.logger.exception("Driver Excel import failed")
        return jsonify(ok=False,error=str(e)),400
    finally:
        temp.unlink(missing_ok=True)


def common_required(f):
    required = ["request_number", "supplier_id", "warehouse_id", "ru_id", "power_date"]
    return [x for x in required if not f.get(x)]


@app.get("/")
def index():
    con = db()
    data = {
        "suppliers": con.execute("SELECT * FROM suppliers ORDER BY name").fetchall(),
        "warehouses": con.execute("SELECT * FROM warehouses ORDER BY name").fetchall(),
        "rus": con.execute("SELECT * FROM ru ORDER BY code").fetchall(),
        "recent": con.execute("""
          SELECT p.*, s.name supplier_name, w.name warehouse_name, r.code ru_code
          FROM powers p
          LEFT JOIN suppliers s ON s.id=p.supplier_id
          LEFT JOIN warehouses w ON w.id=p.warehouse_id
          LEFT JOIN ru r ON r.id=p.ru_id
          ORDER BY p.id DESC LIMIT 50
        """).fetchall()
    }
    con.close()
    data["today"] = date.today().isoformat()
    data["tomorrow"] = (date.today() + timedelta(days=1)).isoformat()
    return render_template("index.html", **data)


@app.get("/admin")
def admin():
    con = db()
    data = {
        "suppliers": con.execute("SELECT * FROM suppliers ORDER BY name").fetchall(),
        "warehouses": con.execute("SELECT * FROM warehouses ORDER BY name").fetchall(),
        "rus": con.execute("SELECT * FROM ru ORDER BY code").fetchall(),
        "drivers": con.execute("SELECT * FROM drivers ORDER BY surname,first_name").fetchall(),
        "vehicles": con.execute("""
          SELECT v.*, d.surname, d.first_name FROM vehicles v
          LEFT JOIN drivers d ON d.id=v.driver_id ORDER BY v.plate
        """).fetchall()
    }
    con.close()
    return render_template("admin.html", **data)


@app.get("/settings")
def settings_page():
    return render_template("settings.html",
        yandex_token=get_setting("yandex_token"),
        yandex_api_url=get_setting("yandex_api_url", "https://exp.tdsd.pro"),
        yandex_company_id=get_setting("yandex_company_id"),
        yandex_station_id=get_setting("yandex_station_id"))

@app.post("/settings")
def save_settings():
    set_setting("yandex_token", request.form.get("yandex_token", "").strip())
    set_setting("yandex_api_url", request.form.get("yandex_api_url", "https://exp.tdsd.pro").strip() or "https://exp.tdsd.pro")
    set_setting("yandex_company_id", request.form.get("yandex_company_id", "").strip())
    set_setting("yandex_station_id", request.form.get("yandex_station_id", "").strip())
    return redirect(url_for("settings_page", saved=1))

@app.get("/api/driver")
def api_driver():
    s, n = norm(request.args.get("series")), norm(request.args.get("number"))
    con = db()
    row = con.execute("""
      SELECT * FROM drivers
      WHERE replace(replace(upper(passport_series),' ',''),'-','')=?
        AND replace(replace(upper(passport_number),' ',''),'-','')=?
    """, (s, n)).fetchone()
    con.close()
    return jsonify({**dict(row), "phone": phone_fmt(row["phone"])} if row else {"found": False})


@app.get("/api/vehicle")
def api_vehicle():
    p = plate_norm(request.args.get("plate"))
    con = db()
    row = con.execute("""
      SELECT * FROM vehicles
      WHERE upper(replace(replace(plate,' ',''),'-',''))=?
    """, (p,)).fetchone()
    con.close()
    return jsonify(dict(row) if row else {"found": False})


@app.get("/api/ru")
def api_ru():
    con = db()
    rid = request.args.get("id")
    if rid:
        row = con.execute("SELECT * FROM ru WHERE id=?", (rid,)).fetchone()
        con.close()
        return jsonify(dict(row) if row else {})
    q = (request.args.get("q") or "").upper().strip()
    rows = con.execute("""
      SELECT * FROM ru
      WHERE upper(code) LIKE ? OR upper(city) LIKE ?
      ORDER BY code
    """, (f"%{q}%", f"%{q}%")).fetchall()
    con.close()
    return jsonify([dict(x) for x in rows])


def insert_row(table, fields, values, duplicate):
    con = db()
    try:
        con.execute(
            f"INSERT INTO {table}({','.join(fields)}) VALUES({','.join(['?']*len(fields))})",
            values
        )
        con.commit()
        row = con.execute("SELECT * FROM " + table + " WHERE id=last_insert_rowid()").fetchone()
        return jsonify(ok=True, row=dict(row))
    except sqlite3.IntegrityError:
        return jsonify(ok=False, error=duplicate), 400
    finally:
        con.close()


@app.post("/api/supplier")
def add_supplier():
    f = request.form
    return insert_row("suppliers", ["name","inn","legal_form","email"],
        [f.get("name","").strip(), f.get("inn","").strip(),
         f.get("legal_form","").strip(), f.get("email","").strip()],
        "Поставщик с таким названием уже есть.")


@app.post("/api/warehouse")
def add_warehouse():
    f = request.form
    return insert_row("warehouses", ["name","address","contact"],
        [f.get("name","").strip(), f.get("address","").strip(), f.get("contact","").strip()],
        "Склад с таким названием уже есть.")


@app.post("/api/ru")
def add_ru():
    f = request.form
    return insert_row("ru", ["code","city","recipient","inn","address","rate","delivery_days"],
        [f.get("code","").strip().upper(), f.get("city","").strip(),
         f.get("recipient","").strip(), f.get("inn","").strip(), f.get("address","").strip(),
         parse_float(f.get("rate")), int(f["delivery_days"]) if f.get("delivery_days") else None],
        "Такой RU уже есть.")


@app.post("/api/driver")
def add_driver():
    f = request.form
    sc = code_fmt(f.get("subdivision_code"))
    if sc and len(digits(sc)) != 6:
        return jsonify(ok=False, error="Код подразделения должен быть в формате 000-000."), 400
    return insert_row("drivers",
        ["passport_series","passport_number","surname","first_name","patronymic","citizenship",
         "birth_date","issued_by","issue_date","registration","subdivision_code","phone"],
        [norm(f.get("passport_series")), norm(f.get("passport_number")),
         f.get("surname","").strip(), f.get("first_name","").strip(), f.get("patronymic","").strip(),
         f.get("citizenship","Россия").strip(), f.get("birth_date","").strip(),
         f.get("issued_by","").strip(), f.get("issue_date","").strip(),
         f.get("registration","").strip(), sc, phone_fmt(f.get("phone"))],
        "Водитель с таким паспортом уже есть.")


@app.post("/api/base/<table>/<int:row_id>")
def update_base(table, row_id):
    allowed = {
        "supplier": ("suppliers", ["name", "inn", "legal_form", "email"]),
        "warehouse": ("warehouses", ["name", "address", "contact"]),
        "ru": ("ru", ["code", "city", "delivery_days", "rate", "recipient", "inn", "address"]),
        "driver": ("drivers", ["passport_series", "passport_number", "surname", "first_name", "patronymic", "subdivision_code", "phone"]),
        "vehicle": ("vehicles", ["plate", "make", "trailer_plate", "driver_id"]),
    }
    if table not in allowed:
        return jsonify(ok=False, error="Неизвестный раздел базы."), 400
    db_table, fields = allowed[table]
    f=request.form
    vals={}
    for fld in fields:
        val=f.get(fld, "").strip()
        if fld in ("passport_series", "passport_number"):
            val=norm(val)
        elif fld == "plate" or fld == "trailer_plate":
            val=plate_norm(val)
        elif fld == "phone":
            val=phone_fmt(val)
        elif fld == "subdivision_code":
            val=code_fmt(val)
            if val and len(digits(val)) != 6:
                return jsonify(ok=False,error="Код подразделения должен быть в формате 000-000."),400
        elif fld == "code":
            val=val.upper()
        elif fld == "delivery_days":
            val=int(val) if val else None
        elif fld == "rate":
            val=parse_float(val)
        elif fld == "driver_id":
            val=int(val) if val else None
        vals[fld]=val
    if table == "supplier" and not vals["name"]:
        return jsonify(ok=False,error="Введите название поставщика."),400
    if table == "warehouse" and (not vals["name"] or not vals["address"]):
        return jsonify(ok=False,error="Название и адрес склада обязательны."),400
    if table == "ru" and not vals["code"]:
        return jsonify(ok=False,error="Введите RU."),400
    if table == "driver" and (not vals["passport_series"] or not vals["passport_number"] or not vals["surname"] or not vals["first_name"]):
        return jsonify(ok=False,error="Серия, номер паспорта и ФИО обязательны."),400
    if table == "vehicle" and not vals["plate"]:
        return jsonify(ok=False,error="Введите госномер."),400
    con=db()
    try:
        sets=", ".join(f"{x}=?" for x in fields)
        con.execute(f"UPDATE {db_table} SET {sets} WHERE id=?", [vals[x] for x in fields]+[row_id])
        if con.total_changes == 0:
            return jsonify(ok=False,error="Запись не найдена."),404
        con.commit()
        row=con.execute(f"SELECT * FROM {db_table} WHERE id=?",(row_id,)).fetchone()
        return jsonify(ok=True,row=dict(row))
    except sqlite3.IntegrityError as e:
        con.rollback()
        return jsonify(ok=False,error="Нельзя сохранить: такая запись уже существует."),400
    finally:
        con.close()


@app.get("/api/drivers")
def api_drivers():
    con = db()
    rows = con.execute("SELECT id,surname,first_name FROM drivers ORDER BY surname,first_name").fetchall()
    con.close()
    return jsonify([dict(x) for x in rows])


@app.post("/api/vehicle")
def add_vehicle():
    f = request.form
    p = plate_norm(f.get("plate"))
    if not p:
        return jsonify(ok=False, error="Введите госномер."), 400
    return insert_row("vehicles", ["plate","make","trailer_plate","driver_id"],
        [p, f.get("make","").strip(), plate_norm(f.get("trailer_plate")),
         int(f["driver_id"]) if f.get("driver_id") else None],
        "Автомобиль с таким госномером уже есть.")


def resolve_driver_and_vehicle(con, f):
    driver_id = None
    ps, pn = norm(f.get("passport_series")), norm(f.get("passport_number"))
    if ps and pn:
        d = con.execute("""
          SELECT * FROM drivers
          WHERE replace(replace(upper(passport_series),' ',''),'-','')=?
            AND replace(replace(upper(passport_number),' ',''),'-','')=?
        """, (ps, pn)).fetchone()
        if not d and f.get("surname") and f.get("first_name"):
            sc = code_fmt(f.get("subdivision_code"))
            if sc and len(digits(sc)) != 6:
                raise ValueError("Код подразделения должен быть в формате 000-000.")
            con.execute("""
              INSERT INTO drivers
              (passport_series,passport_number,surname,first_name,patronymic,citizenship,
               birth_date,issued_by,issue_date,registration,subdivision_code,phone)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
            """, (ps, pn, f.get("surname","").strip(), f.get("first_name","").strip(),
                  f.get("patronymic","").strip(), f.get("citizenship","Россия").strip(),
                  f.get("birth_date","").strip(), f.get("issued_by","").strip(),
                  f.get("issue_date","").strip(), f.get("registration","").strip(),
                  sc, phone_fmt(f.get("phone"))))
            d = con.execute("SELECT * FROM drivers WHERE id=last_insert_rowid()").fetchone()
        if d:
            driver_id = d["id"]

    vehicle_id = None
    vp = plate_norm(f.get("plate"))
    if vp:
        v = con.execute("""
          SELECT * FROM vehicles
          WHERE upper(replace(replace(plate,' ',''),'-',''))=?
        """, (vp,)).fetchone()
        if not v:
            # Vehicle is added automatically as soon as a plate is supplied.
            con.execute("INSERT INTO vehicles(plate,make,trailer_plate,driver_id) VALUES(?,?,?,?)",
                        (vp, f.get("make","").strip(), plate_norm(f.get("trailer_plate")), driver_id))
            v = con.execute("SELECT * FROM vehicles WHERE id=last_insert_rowid()").fetchone()
        elif driver_id and not v["driver_id"]:
            con.execute("UPDATE vehicles SET driver_id=? WHERE id=?", (driver_id, v["id"]))
            v = con.execute("SELECT * FROM vehicles WHERE id=?", (v["id"],)).fetchone()
        vehicle_id = v["id"]
    return driver_id, vehicle_id


def build_outputs(con, f, items, power_id, old_excel=None, old_pdf=None):
    request_number = f["request_number"].strip()
    shipment = f["shipment_date"]
    stem = safe_name(f"Доверенность на {date_ru(shipment)} № {request_number}")
    excel_path = OUTPUT / (stem + ".xlsx")
    pdf_path = OUTPUT / (stem + ".pdf")

    f = dict(f)
    make_excel(f, items, excel_path)
    make_pdf(f, items, pdf_path)
    if old_excel:
        old = Path(old_excel)
        if old.exists() and old.resolve() != excel_path.resolve():
            old.unlink()
    if old_pdf:
        old = Path(old_pdf)
        if old.exists() and old.resolve() != pdf_path.resolve():
            old.unlink()
    return str(excel_path), str(pdf_path), excel_path.name, pdf_path.name


@app.post("/create")
def create():
    f = request.form
    miss = common_required(f)
    items = collect_items(f)
    if not items:
        miss.append("cargo[]")
    if miss:
        return "Не заполнены: " + ", ".join(miss), 400
    # Даты вводятся пользователем. По умолчанию интерфейс предлагает +1 день,
    # но дата отгрузки может быть любой и сервер не ограничивает её.
    try:
        power_date = date.fromisoformat(f.get("power_date", ""))
        shipment_date = date.fromisoformat(f.get("shipment_date", ""))
        arrival_date = date.fromisoformat(f.get("arrival_date", "")) if f.get("arrival_date") else None
    except Exception:
        return "Неверный формат даты.", 400

    con = db()
    try:
        driver_id, vehicle_id = resolve_driver_and_vehicle(con, f)
        fdata = f.to_dict(flat=True)
        fdata["driver_id"] = str(driver_id or "")
        fdata["vehicle_id"] = str(vehicle_id or "")
        fdata["shipment_date"] = shipment_date.isoformat()
        ru = con.execute("SELECT * FROM ru WHERE id=?", (int(f["ru_id"]),)).fetchone()
        unload = ""
        if ru and ru["delivery_days"] is not None:
            unload = (shipment_date + timedelta(days=int(ru["delivery_days"]))).isoformat()

        now = datetime.now().isoformat(timespec="seconds")
        cur = con.execute("""
          INSERT INTO powers
          (request_number,created_at,power_date,supplier_id,warehouse_id,driver_id,vehicle_id,ru_id,
           yandex_most,etrn,tk,application,arrival_date,cargo,quantity,places,contract_no,shipment_date,unload_date,rate,ml)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (f["request_number"].strip(), now, power_date.isoformat(),
              int(f["supplier_id"]), int(f["warehouse_id"]), driver_id, vehicle_id, int(f["ru_id"]),
              f.get("yandex_most","").strip(), f.get("etrn","").strip(), f.get("tk","").strip(), f.get("application","").strip(), arrival_date.isoformat() if arrival_date else unload,
              items[0]["cargo"], items[0]["quantity"], items[0]["places"],
              f.get("contract_no","").strip(), shipment_date.isoformat(), unload,
              ru["rate"] if ru else None, f.get("ml","").strip()))
        power_id = cur.lastrowid
        for item in items:
            con.execute("INSERT INTO cargo_items(power_id,cargo,quantity,places) VALUES(?,?,?,?)",
                        (power_id, item["cargo"], item["quantity"], item["places"]))
        con.commit()

        # Files are generated only on explicit request from "Все доверенности".
        # Keep database record clean; no automatic Excel/PDF generation.
        con.commit()
        return redirect(url_for("powers"))
    except Exception as e:
        con.rollback()
        app.logger.exception("Creation failed")
        return "Ошибка создания: " + str(e), 500
    finally:
        con.close()


@app.get("/done/<int:power_id>")
def done(power_id):
    con = db()
    p = con.execute("SELECT * FROM powers WHERE id=?", (power_id,)).fetchone()
    con.close()
    if not p:
        abort(404)
    return render_template("done.html", p=p)


def power_form_data(con, p):
    data = dict(p)
    items = [dict(x) for x in con.execute(
        "SELECT * FROM cargo_items WHERE power_id=? ORDER BY id", (p["id"],)
    ).fetchall()]
    if not items and p["cargo"]:
        items = [{"cargo":p["cargo"],"quantity":p["quantity"],"places":p["places"]}]
    return data, items


@app.get("/edit/<int:power_id>")
def edit_power(power_id):
    con = db()
    p = con.execute("""
      SELECT p.*, d.passport_series driver_passport_series,d.passport_number driver_passport_number,
             d.surname driver_surname,d.first_name driver_first,d.patronymic driver_patronymic,
             d.citizenship driver_citizenship,d.birth_date driver_birth_date,d.issue_date driver_issue_date,
             d.subdivision_code driver_subdivision_code,d.phone driver_phone,d.issued_by driver_issued_by,
             d.registration driver_registration,v.plate vehicle_plate,v.make vehicle_make,v.trailer_plate vehicle_trailer,
             r.code ru_code,r.city ru_city,r.recipient ru_recipient,r.inn ru_inn,r.address ru_address,
             r.delivery_days ru_delivery_days
      FROM powers p
      LEFT JOIN drivers d ON d.id=p.driver_id
      LEFT JOIN vehicles v ON v.id=p.vehicle_id
      LEFT JOIN ru r ON r.id=p.ru_id
      WHERE p.id=?
    """, (power_id,)).fetchone()
    if not p:
        con.close(); abort(404)
    data, items = power_form_data(con, p)
    context = {
        "suppliers": con.execute("SELECT * FROM suppliers ORDER BY name").fetchall(),
        "warehouses": con.execute("SELECT * FROM warehouses ORDER BY name").fetchall(),
        "rus": con.execute("SELECT * FROM ru ORDER BY code").fetchall(),
        "power": data, "items": items
    }
    con.close()
    return render_template("edit.html", **context)


@app.post("/edit/<int:power_id>")
def save_edit(power_id):
    f = request.form
    items = collect_items(f)
    miss = common_required(f)
    if not items: miss.append("cargo[]")
    if miss: return "Не заполнены: " + ", ".join(miss), 400
    try:
        power_date = date.fromisoformat(f["power_date"])
    except Exception:
        return "Неверная дата доверенности.", 400
    try:
        shipment = date.fromisoformat(f.get("shipment_date", ""))
        arrival_date = date.fromisoformat(f.get("arrival_date", "")) if f.get("arrival_date") else None
    except Exception:
        return "Неверный формат даты отгрузки/прибытия.", 400

    con = db()
    try:
        p = con.execute("SELECT * FROM powers WHERE id=?", (power_id,)).fetchone()
        if not p: abort(404)
        driver_id, vehicle_id = resolve_driver_and_vehicle(con, f)
        ru = con.execute("SELECT * FROM ru WHERE id=?", (int(f["ru_id"]),)).fetchone()
        unload = ""
        if ru and ru["delivery_days"] is not None:
            unload = shipment + timedelta(days=int(ru["delivery_days"]))
            unload = unload.isoformat()

        con.execute("""
          UPDATE powers SET request_number=?,power_date=?,supplier_id=?,warehouse_id=?,
          driver_id=?,vehicle_id=?,ru_id=?,yandex_most=?,etrn=?,tk=?,application=?,arrival_date=?,cargo=?,quantity=?,places=?,
          contract_no=?,shipment_date=?,unload_date=?,rate=?,ml=? WHERE id=?
        """, (f["request_number"].strip(), power_date.isoformat(), int(f["supplier_id"]),
              int(f["warehouse_id"]), driver_id, vehicle_id, int(f["ru_id"]),
              f.get("yandex_most","").strip(), f.get("etrn","").strip(), f.get("tk","").strip(), f.get("application","").strip(), arrival_date.isoformat() if arrival_date else unload,
              items[0]["cargo"], items[0]["quantity"], items[0]["places"],
              f.get("contract_no","").strip(), shipment.isoformat(), unload,
              ru["rate"] if ru else None, f.get("ml","").strip(), power_id))
        con.execute("DELETE FROM cargo_items WHERE power_id=?", (power_id,))
        for item in items:
            con.execute("INSERT INTO cargo_items(power_id,cargo,quantity,places) VALUES(?,?,?,?)",
                        (power_id,item["cargo"],item["quantity"],item["places"]))
        con.commit()

        # Editing invalidates previously generated files; they will be generated
        # again only when the user explicitly presses Excel/PDF.
        for old_file in (p["output_file"], p["pdf_file"]):
            if old_file:
                try:
                    Path(old_file).unlink(missing_ok=True)
                except Exception:
                    pass
        con.execute("UPDATE powers SET output_file=NULL,pdf_file=NULL WHERE id=?", (power_id,))
        con.commit()
        return redirect(url_for("powers"))
    except Exception as e:
        con.rollback()
        app.logger.exception("Edit failed")
        return "Ошибка сохранения: " + str(e), 500
    finally:
        con.close()



def make_excel_all(rows, out):
    """Create one Excel file containing all saved powers, preserving the user's template."""
    wb = openpyxl.load_workbook(TEMPLATE, data_only=False)
    cached = openpyxl.load_workbook(TEMPLATE, data_only=True)
    ws, cv = wb["Расход"], cached["Расход"]

    for rr in range(1, ws.max_row + 1):
        for cc in range(1, ws.max_column + 1):
            cell = ws.cell(rr, cc)
            if isinstance(cell.value, str) and cell.value.startswith("="):
                cell.value = cv.cell(rr, cc).value

    con = db()
    for p in rows:
        f = dict(p)
        # get full power context and all cargo rows
        items = [dict(x) for x in con.execute(
            "SELECT cargo,quantity,places FROM cargo_items WHERE power_id=? ORDER BY id",
            (p["id"],)
        ).fetchall()]
        if not items:
            items = [{"cargo": p["cargo"], "quantity": p["quantity"], "places": p["places"]}]

        s, w, r, d, v = fetch_power_context(con, f)
        unload = p["unload_date"] or ""
        base_map = {
            "A": p["request_number"] or "", "B": s["name"] if s else "",
            "C": w["name"] if w else "", "D": d["surname"] if d else "",
            "E": d["first_name"] if d else "", "F": d["patronymic"] if d else "",
            "G": d["citizenship"] if d else "", "K": d["passport_series"] if d else "",
            "L": d["passport_number"] if d else "", "M": d["issued_by"] if d else "",
            "Q": d["registration"] if d else "", "R": v["make"] if v else "",
            "S": v["plate"] if v else "", "T": v["trailer_plate"] if v else "",
            "U": phone_fmt(d["phone"]) if d else "", "V": r["recipient"] if r else "",
            "W": r["inn"] if r else "", "X": p["yandex_most"] or "",
            "Y": r["code"] if r else "", "AC": p["contract_no"] or "",
            "AD": p["shipment_date"] or "", "AE": unload, "AF": s["inn"] if s else "",
            "AG": w["contact"] if w else "", "AH": w["address"] if w else "",
            "AI": r["delivery_days"] if r else None, "AJ": r["rate"] if r else None,
            "AK": p["ml"] or "", "AM": p["tk"] or "", "AN": p["application"] or "", "AO": p["arrival_date"] or "", "AL": s["legal_form"] if s else "",
            "AT": s["email"] if s else "",
            "AW": date.fromisoformat(p["shipment_date"]).isocalendar().week if p["shipment_date"] else ""
        }
        if d and d["birth_date"]:
            try:
                x=date.fromisoformat(d["birth_date"]); base_map.update({"H":x.day,"I":x.month,"J":x.year})
            except Exception: pass
        if d and d["issue_date"]:
            try:
                x=date.fromisoformat(d["issue_date"]); base_map.update({"N":x.day,"O":x.month,"P":x.year})
            except Exception: pass

        for item in items:
            row=first_empty(ws)
            copy_row_style(ws,4,row)
            m=dict(base_map)
            m["Z"]=item.get("cargo","")
            m["AA"]=item.get("quantity")
            m["AB"]=item.get("places")
            for col,val in m.items():
                ws[f"{col}{row}"]=val
    con.close()

    for sh in ("RU","данные"):
        if sh in wb.sheetnames:
            del wb[sh]
    wb.save(out)
    openpyxl.load_workbook(out, read_only=True).close()


@app.post("/delete/<int:power_id>")
def delete_power(power_id):
    con=db()
    try:
        p=con.execute("SELECT output_file,pdf_file FROM powers WHERE id=?",(power_id,)).fetchone()
        if not p:
            return "Заявка не найдена.",404
        con.execute("DELETE FROM powers WHERE id=?",(power_id,))
        con.commit()
        for fld in ("output_file","pdf_file"):
            if p[fld]:
                try: Path(p[fld]).unlink(missing_ok=True)
                except Exception: pass
        return redirect(url_for("powers"))
    finally:
        con.close()


@app.get("/powers")
def powers():
    con = db()
    q = request.args.get("q","").strip()
    supplier = request.args.get("supplier","")
    ru = request.args.get("ru","")
    date_from = request.args.get("date_from","")
    date_to = request.args.get("date_to","")
    missing = request.args.get("missing","")
    where, args = [], []
    if q:
        where.append("(p.request_number LIKE ? OR d.surname LIKE ? OR v.plate LIKE ? OR r.code LIKE ?)")
        args += [f"%{q}%"] * 4
    if supplier:
        where.append("p.supplier_id=?"); args.append(supplier)
    if ru:
        where.append("p.ru_id=?"); args.append(ru)
    if date_from:
        where.append("p.shipment_date>=?"); args.append(date_from)
    if date_to:
        where.append("p.shipment_date<=?"); args.append(date_to)
    if missing == "driver": where.append("p.driver_id IS NULL")
    elif missing == "vehicle": where.append("p.vehicle_id IS NULL")
    elif missing == "both": where.append("(p.driver_id IS NULL OR p.vehicle_id IS NULL)")

    sql = """
      SELECT p.*,s.name supplier_name,w.name warehouse_name,r.code ru_code,r.city ru_city,
             d.surname driver_surname,d.first_name driver_first,v.plate vehicle_plate
      FROM powers p
      LEFT JOIN suppliers s ON s.id=p.supplier_id
      LEFT JOIN warehouses w ON w.id=p.warehouse_id
      LEFT JOIN ru r ON r.id=p.ru_id
      LEFT JOIN drivers d ON d.id=p.driver_id
      LEFT JOIN vehicles v ON v.id=p.vehicle_id
    """
    if where: sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY (p.driver_id IS NULL OR p.vehicle_id IS NULL) DESC, p.id DESC"
    rows = con.execute(sql, args).fetchall()
    suppliers = con.execute("SELECT * FROM suppliers ORDER BY name").fetchall()
    rus = con.execute("SELECT * FROM ru ORDER BY code").fetchall()
    con.close()
    return render_template("powers.html", powers=rows, suppliers=suppliers, rus=rus, filters=request.args)



@app.get("/weekly-report")
def weekly_report():
    selected = request.args.get("date") or date.today().isoformat()
    try:
        start, end = week_bounds(selected)
    except Exception:
        selected = date.today().isoformat()
        start, end = week_bounds(selected)
    con = db()
    rows = con.execute("""
      SELECT p.*, w.name warehouse_name, r.address ru_address,
             d.surname driver_surname, d.first_name driver_first, d.patronymic driver_patronymic,
             d.phone driver_phone, v.plate vehicle_plate
      FROM powers p
      LEFT JOIN warehouses w ON w.id=p.warehouse_id
      LEFT JOIN ru r ON r.id=p.ru_id
      LEFT JOIN drivers d ON d.id=p.driver_id
      LEFT JOIN vehicles v ON v.id=p.vehicle_id
      WHERE p.shipment_date >= ? AND p.shipment_date <= ?
      ORDER BY p.shipment_date, p.id
    """, (start.isoformat(), end.isoformat())).fetchall()
    con.close()
    return render_template("weekly_report.html", selected=selected, start=start, end=end, powers=rows)


@app.get("/weekly-report/export")
def weekly_report_export():
    selected = request.args.get("date") or date.today().isoformat()
    try:
        start, end = week_bounds(selected)
    except Exception:
        return "Неверная дата.", 400
    con = db()
    rows = con.execute("""
      SELECT p.*, w.name warehouse_name, r.address ru_address,
             d.surname driver_surname, d.first_name driver_first, d.patronymic driver_patronymic,
             d.phone driver_phone, v.plate vehicle_plate
      FROM powers p
      LEFT JOIN warehouses w ON w.id=p.warehouse_id
      LEFT JOIN ru r ON r.id=p.ru_id
      LEFT JOIN drivers d ON d.id=p.driver_id
      LEFT JOIN vehicles v ON v.id=p.vehicle_id
      WHERE p.shipment_date >= ? AND p.shipment_date <= ?
      ORDER BY p.shipment_date, p.id
    """, (start.isoformat(), end.isoformat())).fetchall()
    con.close()
    name = safe_name(f"Отчет движение {start.isocalendar().week} неделя") + ".xlsx"
    path = OUTPUT / name
    make_weekly_report(rows, start, end, path)
    return send_file(path, as_attachment=True, download_name=name,
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.get("/export-all")
def export_all():
    con = db()
    rows = con.execute("SELECT * FROM powers ORDER BY id DESC").fetchall()
    con.close()
    if not rows:
        return "Нет доверенностей для выгрузки.", 404
    name = "Все доверенности.xlsx"
    path = OUTPUT / name
    make_excel_all(rows, path)
    return send_file(path, as_attachment=True, download_name=name,
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")



def _power_for_generation(power_id):
    con=db()
    p=con.execute("SELECT * FROM powers WHERE id=?", (power_id,)).fetchone()
    if not p:
        con.close()
        abort(404)
    data=dict(p)
    items=[dict(x) for x in con.execute(
        "SELECT cargo,quantity,places FROM cargo_items WHERE power_id=? ORDER BY id",(power_id,)
    ).fetchall()]
    if not items:
        items=[{"cargo":p["cargo"],"quantity":p["quantity"],"places":p["places"]}]
    con.close()
    return data,items


@app.get("/generate/<int:power_id>/excel")
def generate_excel(power_id):
    f, items = _power_for_generation(power_id)
    path = OUTPUT / (safe_name(f"Доверенность на {date_ru(f['shipment_date'])} № {f['request_number']}") + ".xlsx")
    make_excel(f,items,path)
    con=db()
    con.execute("UPDATE powers SET output_file=? WHERE id=?",(str(path),power_id))
    con.commit(); con.close()
    return send_file(path,as_attachment=True,download_name=path.name,
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.get("/generate/<int:power_id>/pdf")
def generate_pdf(power_id):
    f, items = _power_for_generation(power_id)
    path=OUTPUT / (safe_name(f"Доверенность на {date_ru(f['shipment_date'])} № {f['request_number']}") + ".pdf")
    make_pdf(f,items,path)
    con=db()
    con.execute("UPDATE powers SET pdf_file=? WHERE id=?",(str(path),power_id))
    con.commit(); con.close()
    return send_file(path,as_attachment=True,download_name=path.name,
                     mimetype="application/pdf")


@app.get("/download/<path:filename>")
def download(filename):
    p = (OUTPUT / Path(filename).name).resolve()
    if p.parent != OUTPUT.resolve() or not p.exists():
        abort(404)
    return send_file(p, as_attachment=True)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8087)
